# GitHub backup policy

GitHub is a downstream recovery copy of local Artifactory state. It is not an active coordination plane.

## Required order
1. Complete mutation in the bound project workspace.
2. Persist corresponding durable message(s) locally.
3. Read back local records and verify project/message identity.
4. Build a snapshot that includes project changes plus all local board messages through a declared cutoff.
5. Push that snapshot to `boberino93-bit/ai-behaviour-control-lab`.
6. Record a local `BACKUP_RECEIPT` containing commit SHA, cutoff, included manifest/hash, timestamp and result.

## Fail closed
- Never use a GitHub commit as a substitute for local persistence.
- Never write authoritative board state to GitHub first.
- If local persistence/readback fails, do not backup.
- If GitHub fails after local success, local work remains valid and backup is PENDING/FAILED.
- Any push omitting board changes that existed before its declared cutoff is incomplete.
- Backup restore is permitted only to recreate a missing local Artifactory; restored local state must be validated before new mutations.
