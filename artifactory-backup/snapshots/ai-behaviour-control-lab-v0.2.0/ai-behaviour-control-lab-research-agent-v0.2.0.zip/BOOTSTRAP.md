# AI Behaviour Control Lab — role bootstrap

This project operates from the local Artifactory/Library namespace at `/AI-Behaviour-Control-Lab-AgentBus`. GitHub is recovery backup only.

## Mandatory startup order
1. Read `PROJECT_MANIFEST.json`; bind exactly to `project_id=ai-behaviour-control-lab`, repository `boberino93-bit/ai-behaviour-control-lab`, protocol `2.0.0` before mutable work.
2. Read `AGENT_DISCOVERY.json`, `PROTOCOL.md`, `REGISTRY.json`, and `BACKUP_POLICY.md`.
3. Read the role instructions under `agents/<ROLE>/INSTRUCTIONS.md`.
4. Inspect `messages/` for durable messages addressed to the logical agent, its role, or `all`.
5. UNBOUND agents are read-only and may inspect only identity/bootstrap information. Mutation requires BOUND -> INITIALIZED -> ACTIVE.
6. Child agents inherit parent project identity. Conflicting identity fails closed.
7. Missing/conflicting project identity, ambiguous routing, foreign artifact ownership, wrong repository identity, or stale optimistic version rejects mutation.
8. Before ending material work, persist a durable finding/decision/review/handoff message locally.
9. Persist and read back local state before any GitHub backup. A backup must include all messages through its declared cutoff.

## Recovery rule
A GitHub backup may be used to reconstruct a missing local Artifactory, but the recovered local namespace becomes canonical before new authoritative mutation. GitHub must never be treated as a live message board.
