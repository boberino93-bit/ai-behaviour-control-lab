# AI Behaviour Control Lab coordination protocol — v2.0.0

## State authority and identity
Local Artifactory `/AI-Behaviour-Control-Lab-AgentBus` is canonical. GitHub is backup-only. Every active agent and every mutable resource belongs to exactly one project. `project_id` is an authorization boundary, not descriptive metadata.

## Agent lifecycle
`CREATED -> UNBOUND -> PROJECT_RESOLUTION -> BOUND(project_id) -> INITIALIZED -> ACTIVE -> DRAINING/PAUSED -> TERMINATED`. UNBOUND agents cannot mutate state. Child agents inherit parent `project_id`; conflicting child identity is rejected.

## Message envelope
New messages use `ai-behaviour-control-lab/agentbus-message/v2` and carry `protocol_version`, globally unique `message_id`, correlation/causation/idempotency data, sender and destination project/agent identity, task context, message type, sequence, timestamps/expiry, priority, capability requirements, artifact references, payload, and payload hash. Legacy v1 records are readable history only and cannot authorize new mutations.

## Routing and authorization
Internal routing requires sender.project_id == destination.project_id == `ai-behaviour-control-lab`. Ambiguous, expired, malformed, wrong-project, unsupported-protocol, or unauthorized messages are rejected or quarantined. Cross-project exchange requires a distinct bridge capability and sanitized copy-by-value export; ordinary internal channels never bridge projects.

## Tasks, claims, locks and leases
Tasks are project-owned and versioned. Work claims use atomic project-namespaced leases with holder instance, acquisition/expiry and renewable heartbeat. Expired leases are recoverable. Versioned writes reject stale expected_version. Duplicate idempotency keys return the prior result rather than repeating a mutation.

## Artifacts and repository boundary
Artifacts carry immutable project ownership and provenance. Paths are canonicalized before write and must remain under the project root. Source/repository operations must match repository identity `boberino93-bit/ai-behaviour-control-lab`. Foreign or ambiguous repository targets fail closed.

## Packages
PRIMARY, MANAGER and RESEARCH packages share the same protocol/runtime but have role-specific instructions and least-privilege capabilities. Relevant protocol/bootstrap/schema/role changes require all dependent packages to rebuild and validate as one release set.

## Audit / acknowledgements
Meaningful operations preserve project, logical agent, instance, task, triggering message, resource, prior version, result and timestamp. Delivery state is distinct: RECEIVED, ACCEPTED, STARTED, COMPLETED, FAILED, REJECTED, QUARANTINED, EXPIRED, DUPLICATE, UNAUTHORIZED, PROTOCOL_MISMATCH.
