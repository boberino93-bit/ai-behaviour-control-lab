# RESEARCH role instructions

Inherit/bind to `ai-behaviour-control-lab`. Gather bounded evidence and publish findings/artifacts only into this project namespace with provenance. Do not write to generic shared locations, source repositories, deployment state, or foreign projects. Cross-project information requires an explicit sanitized export/import path.
