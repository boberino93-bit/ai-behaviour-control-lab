from __future__ import annotations
from pathlib import Path
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib, json, os, tempfile, time, uuid
import fcntl

ROOT = Path('/AI-Behaviour-Control-Lab-AgentBus').resolve()
MANIFEST = json.loads((ROOT/'PROJECT_MANIFEST.json').read_text())
PROJECT_ID = MANIFEST['project_id']
REPOSITORY_IDENTITY = MANIFEST['repository_identity']
PROTOCOL_VERSION = MANIFEST['protocol_version']

class GuardError(RuntimeError): pass
class StaleWrite(GuardError): pass


def canonical_project_path(path: str | Path) -> Path:
    p = Path(path)
    if not p.is_absolute(): p = ROOT / p
    p = p.resolve()
    if p != ROOT and ROOT not in p.parents:
        raise GuardError(f'path escapes project root: {p}')
    return p


def current_project_state() -> dict:
    return json.loads((ROOT/'control/PROJECT_STATE.json').read_text())


def assert_mutations_enabled() -> None:
    s=current_project_state()
    if s.get('project_id') != PROJECT_ID or not s.get('mutations_enabled') or s.get('status') in {'PAUSED','DRAINING','TERMINATED'}:
        raise GuardError('project mutations disabled')


def assert_project(requester_project_id: str, target_project_id: str = PROJECT_ID) -> None:
    if requester_project_id != PROJECT_ID or target_project_id != PROJECT_ID or requester_project_id != target_project_id:
        raise GuardError('project identity mismatch')


def assert_repository(repository_identity: str) -> None:
    if repository_identity != REPOSITORY_IDENTITY:
        raise GuardError('repository identity mismatch')


def bind_child(parent_project_id: str, child_claimed_project_id: str | None = None) -> dict:
    assert_project(parent_project_id)
    if child_claimed_project_id not in (None, parent_project_id):
        raise GuardError('child project escape/conflict')
    return {'project_id': parent_project_id, 'binding_state': 'BOUND'}


def authorize_cross_project_exchange(target_project_id: str, capabilities: list[str], sanitized_copy: bool) -> None:
    state=current_project_state()
    allowed=set(MANIFEST.get('allowed_cross_project_links',[]))
    if not state.get('cross_project_exchange_enabled') or 'cross_project_exchange' not in capabilities or target_project_id not in allowed or not sanitized_copy:
        raise GuardError('cross-project exchange denied')


def payload_hash(payload) -> str:
    raw = json.dumps(payload, sort_keys=True, separators=(',',':'), ensure_ascii=False).encode()
    return hashlib.sha256(raw).hexdigest()


def parse_ts(s: str) -> datetime:
    return datetime.fromisoformat(s.replace('Z','+00:00'))


def validate_message(m: dict, now: datetime | None = None) -> None:
    required=['schema','protocol_version','message_id','correlation_id','idempotency_key','sender','destination','message_type','sequence','created_at','priority','capabilities_required','artifact_refs','payload','integrity','status','backup_state']
    missing=[k for k in required if k not in m]
    if missing: raise GuardError('missing message fields: '+','.join(missing))
    if m['schema']!='ai-behaviour-control-lab/agentbus-message/v2': raise GuardError('unsupported message schema')
    if m['protocol_version']!=PROTOCOL_VERSION: raise GuardError('protocol mismatch')
    assert_project(m['sender'].get('project_id'),m['destination'].get('project_id'))
    if m['integrity'].get('payload_hash')!=payload_hash(m['payload']): raise GuardError('payload hash mismatch')
    if m.get('expires_at'):
        now=now or datetime.now(timezone.utc)
        if parse_ts(m['expires_at']) <= now: raise GuardError('expired message')
    for ref in m.get('artifact_refs',[]):
        if ref.get('project_id') != PROJECT_ID: raise GuardError('foreign artifact reference')

@contextmanager
def file_lock(name: str):
    p=ROOT/'state'/f'.{name}.lock'; p.parent.mkdir(parents=True,exist_ok=True)
    with open(p,'a+') as fh:
        fcntl.flock(fh.fileno(), fcntl.LOCK_EX)
        try: yield
        finally: fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


def atomic_write_json(path: str | Path, data: dict) -> None:
    p=canonical_project_path(path); p.parent.mkdir(parents=True, exist_ok=True)
    fd,tmp=tempfile.mkstemp(dir=p.parent, prefix='.'+p.name+'.', text=True)
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as f:
            json.dump(data,f,indent=2,ensure_ascii=False); f.write('\n'); f.flush(); os.fsync(f.fileno())
        os.replace(tmp,p)
    finally:
        if os.path.exists(tmp): os.unlink(tmp)


def append_message(m: dict) -> dict:
    assert_mutations_enabled(); validate_message(m)
    with file_lock('messages'):
        idem=ROOT/'state/idempotency.json'; journal=json.loads(idem.read_text())
        key=m['idempotency_key']
        if key in journal['entries']:
            return {'outcome':'DUPLICATE','prior':journal['entries'][key]}
        stamp=m['created_at'].replace('-','').replace(':','')
        safe=m['message_id'].replace('/','_').replace(':','_')
        path=ROOT/'messages'/f'{stamp}__{safe}.json'
        if path.exists(): return {'outcome':'DUPLICATE','path':str(path)}
        atomic_write_json(path,m)
        got=json.loads(path.read_text()); validate_message(got)
        journal['version']+=1; journal['entries'][key]={'message_id':m['message_id'],'path':str(path),'result':'COMPLETED'}
        atomic_write_json(idem,journal)
        return {'outcome':'ACCEPTED','path':str(path)}


def new_message(*, sender_agent:str, sender_instance:str, sender_role:str, destination_role:str|None, channel:str|None, message_type:str, payload, correlation_id:str, idempotency_key:str, priority='normal', status='COMPLETED', causation_id=None, task=None, artifact_refs=None, sequence=0, expires_at=None, backup_state='LOCAL_ONLY') -> dict:
    mid=f'{PROJECT_ID}:{uuid.uuid4()}'
    return {'schema':'ai-behaviour-control-lab/agentbus-message/v2','protocol_version':PROTOCOL_VERSION,'message_id':mid,'correlation_id':correlation_id,'causation_id':causation_id,'idempotency_key':idempotency_key,
      'sender':{'project_id':PROJECT_ID,'agent_id':sender_agent,'agent_instance_id':sender_instance,'role':sender_role},
      'destination':{'project_id':PROJECT_ID,'agent_id':None,'channel':channel,'role':destination_role},'task':task,
      'message_type':message_type,'sequence':sequence,'created_at':datetime.now(timezone.utc).isoformat().replace('+00:00','Z'),'expires_at':expires_at,'priority':priority,
      'capabilities_required':[],'artifact_refs':artifact_refs or [],'payload':payload,'integrity':{'payload_hash':payload_hash(payload)},'status':status,'backup_state':backup_state}


def claim_task(task_id: str, holder_instance: str, ttl_seconds: int=120, now: float|None=None) -> dict:
    assert_mutations_enabled(); now=now or time.time(); lease_path=ROOT/'leases'/f'{task_id}.lease.json'
    with file_lock('leases'):
        if lease_path.exists():
            cur=json.loads(lease_path.read_text())
            if cur['expires_epoch']>now and cur['holder_agent_instance_id']!=holder_instance:
                raise GuardError('task already leased')
            ver=cur.get('version',0)+1
        else: ver=1
        lease={'project_id':PROJECT_ID,'resource_id':task_id,'holder_agent_instance_id':holder_instance,'acquired_at_epoch':now,'expires_epoch':now+ttl_seconds,'version':ver}
        atomic_write_json(lease_path,lease); return lease


def versioned_update(relpath: str, mutate, expected_version: int, requester_project_id: str=PROJECT_ID) -> dict:
    assert_mutations_enabled(); assert_project(requester_project_id)
    with file_lock('versioned-state'):
        p=canonical_project_path(relpath); cur=json.loads(p.read_text())
        if cur.get('version') != expected_version: raise StaleWrite(f"expected {expected_version} current {cur.get('version')}")
        nxt=mutate(json.loads(json.dumps(cur))); nxt['version']=expected_version+1
        atomic_write_json(p,nxt); return nxt


def set_project_state(*, status: str, mutations_enabled: bool, actor_capabilities: list[str], expected_version: int) -> dict:
    if 'integrate_accepted_state' not in actor_capabilities: raise GuardError('insufficient capability')
    with file_lock('project-state'):
        p=ROOT/'control/PROJECT_STATE.json'; cur=json.loads(p.read_text())
        if cur.get('version')!=expected_version: raise StaleWrite('project state version mismatch')
        cur.update({'status':status,'mutations_enabled':mutations_enabled,'version':expected_version+1,'updated_at':datetime.now(timezone.utc).isoformat().replace('+00:00','Z')})
        atomic_write_json(p,cur); return cur


def verify_backup_cutoff(snapshot_root: str | Path, cutoff_utc: str) -> list[str]:
    snap=Path(snapshot_root); missing=[]
    for p in (ROOT/'messages').glob('*.json'):
        obj=json.loads(p.read_text()); ts=obj.get('created_at') or obj.get('timestamp_utc')
        if ts and ts <= cutoff_utc and not (snap/'messages'/p.name).exists(): missing.append(p.name)
    if missing: raise GuardError('backup missing messages through cutoff: '+','.join(sorted(missing)))
    return []
