# AI Behaviour Control Lab — hardened multi-agent architecture

**Canonical project:** `ai-behaviour-control-lab`  
**Canonical state:** local Artifactory `/AI-Behaviour-Control-Lab-AgentBus`  
**Backup repository:** `boberino93-bit/ai-behaviour-control-lab` (backup only)  
**Protocol:** `2.0.0`

The system is project-bound before mutation, uses fail-closed identity and repository guards, project-scoped messages/tasks/artifacts/leases, optimistic version checks, idempotency, atomic file replacement, and role-specific deployment packages. Shared infrastructure may know about multiple projects; this project's execution context does not gain implicit access to them.

Cross-project exchange is deny-by-default and must use an explicit sanitized copy-by-value bridge. The bridge is not implemented in alpha because this project currently has no approved cross-project exchange capability.

Backup order is local mutation -> durable local messages -> local readback -> snapshot through a declared message cutoff -> GitHub backup -> local receipt.
